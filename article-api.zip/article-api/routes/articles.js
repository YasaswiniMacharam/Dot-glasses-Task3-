const express = require('express');
const router = express.Router();
const db = require('../db');

// POST /articles
router.post('/', async (req, res) => {
  const { title, description, author, status, rating } = req.body;
  try {
    const [result] = await db.execute(
      'INSERT INTO articles (title, description, author, status, rating) VALUES (?, ?, ?, ?, ?)',
      [title, description, author, status, rating]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /articles
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM articles');
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /articles/:id
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM articles WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ message: 'Article not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PUT /articles/:id
router.put('/:id', async (req, res) => {
  const { rating, status } = req.body;
  try {
    const [result] = await db.execute(
      'UPDATE articles SET rating = ?, status = ? WHERE id = ?',
      [rating, status, req.params.id]
    );
    res.json({ message: 'Article updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE /articles/:id
router.delete('/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM articles WHERE id = ?', [req.params.id]);
    res.json({ message: 'Article deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
