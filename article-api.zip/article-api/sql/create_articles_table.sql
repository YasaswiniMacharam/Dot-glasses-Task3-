CREATE DATABASE IF NOT EXISTS article_db;

USE article_db;

CREATE TABLE IF NOT EXISTS articles (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  author VARCHAR(100),
  status VARCHAR(50),
  rating INT
);
